#!/bin/bash

cut -f1,6 "$1"   |
    while read n d ; do
    	  eval echo {1..$n}{1..$d}
    done |
    grep -v N |
    wc -w 
