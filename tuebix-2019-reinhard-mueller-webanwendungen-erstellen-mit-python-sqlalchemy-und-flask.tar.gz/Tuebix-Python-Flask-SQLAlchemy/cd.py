# =============================================================================
# Beispielanwendung für die Tübix: CD-Datenbank
# =============================================================================
# Copyright © 2019 Reinhard Müller <reinhard@fsfe.org>
# This work is free. You can redistribute it and/or modify it under the
# terms of the Do What The Fuck You Want To Public License, Version 2,
# as published by Sam Hocevar. See http://www.wtfpl.net/ for more details.
# =============================================================================


# =============================================================================
# Importe aus den verschiedenen Bibliotheken, die wir verwenden
# =============================================================================

# SQLAlchemy: https://docs.sqlalchemy.org/
from sqlalchemy.ext.hybrid import hybrid_property

# Flask: http://flask.pocoo.org/
from flask import Flask, redirect, render_template

# Flask-SQLAlchemy: https://flask-sqlalchemy.palletsprojects.com/
from flask_sqlalchemy import SQLAlchemy

# WTForms: https://wtforms.readthedocs.io/
from wtforms import StringField, SelectField

# Flask-WTForms: https://flask-wtf.readthedocs.io/
from flask_wtf import FlaskForm


# =============================================================================
# Initialisierungen für Flask
# =============================================================================

# Unser Flask Application-Objekt, der zentrale Dreh- und Angelpunkt für Flask
app = Flask(__name__)

# Ein Schlüssel für Flask-interne Sicherheitsmechanismen
app.config["SECRET_KEY"] = "hajfhajkf"

# Wo die Datenbank liegt
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///cd.db"

# Eine empfohlene Konfigurationseinstellung
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Unser Interface zu Flask-SQLAlchemy
db = SQLAlchemy(app)


# =============================================================================
# Klassen für unser Datenmodell
# =============================================================================

# Für jede Klasse wird in der Datenbank eine Tabelle angelegt, für jede
# Eigenschaft, die von db.Column abgeleitet ist, eine Datenbankspalte. Die
# Namen werden automatisch aus Klassennamen bzw. Eigenschaftsnamen ermittelt.

class Interpret(db.Model):

    # Die tatsächlichen Datenbankspalten, hier eine laufende Nummer, der
    # Vorname und der Nachname
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(64))
    last_name = db.Column(db.String(64))

    # Auch Methoden sind in einer solchen Klasse erlaubt, sie resultieren
    # naturgemäß nicht in einer Datenbankspalte. Eine als "hybrid_property"
    # gekennzeichnete Methode kann die Berechnung einer virtuellen
    # Datenbankspalte definieren, die dann sogar als Bedingung in einer Abfrage
    # verwendet werden kann.
    @hybrid_property
    def display_name(self):
        return self.last_name + ", " + self.first_name

    # Diese Methode dient lediglich dazu, die Ausgabe einer Instanz zu
    # verschönern, z.B. für's Debugging.
    def __repr__(self):
        return "<Interpret {}>".format(self.display_name)


class Cd(db.Model):

    # Auch hier definieren wir wieder zuerst mal die tatsächlichen
    # Datenbankspalten. Die Spalte "interpret_id" wird als Fremdschlüssel auf
    # die Tabelle "interpret" mit dem Primärschlüssel "db" deklariert.
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(64))
    interpret_id = db.Column(db.Integer, db.ForeignKey("interpret.id"))

    # Während die Eigenschaft "interpret_id" eines solchen Objekts immer die
    # fortlaufende Nummer des Interpreten enthält (also den tatsächlichen
    # Inhalt der Datenbankspalte), bekommt die Eigenschaft "interpret" eine
    # Referenz auf das zugehörige Objekt der Klasse "Interpret".
    interpret = db.relationship("Interpret")


# =============================================================================
# Jetzt erst kommt das Web-Interface
# =============================================================================

# In Flask werden Routen definiert, die eine URL mit einer Prozedur verknüpfen.
# Beim Aufruf einer URL wird die Prozedur ausgeführt und deren Rückgabewert als
# Response des Webservers verwendet.
@app.route("/")
def list_cds():

    # Flask arbeitet mit Jinja2-Templates. Als Parameter für das Template
    # verwenden wir einfach eine komplette Liste der CDs.
    return render_template("cd_list.html", cds=Cd.query)

# Diese WTForms-Klasse kümmert sich um Dinge wie das Parsen der POST-Parameter,
# Umwandeln in den richtigen Python-Datentyp, Prüfung der Gültigkeit der
# Eingabe, und auch die Erzeugung der für die einzelnen Felder passenden
# HTML-Elemente.
class CdForm(FlaskForm):
    title = StringField(label="Titel:")
    interpret_id = SelectField(label="Interpret:")

# Hier haben wir eine Route, die einen variablen Teil hat. Dieser wird
# automatisch in einen Parameter für die verknüpfte Prozedur umgewandelt.
# Außerdem definieren wir, dass außer dem Standard ("GET") auch noch "POST"
# zulässig ist. Diese Route wird nämlich für den Aufruf des Formulars mit "GET"
# aufgerufen, beim Speichern dann mit "POST".
@app.route("/cd/<int:id>", methods=("GET", "POST"))
def edit_cd(id):

    # Zuerst holen wir die zu bearbeitende CD aus der Datenbank.
    cd = Cd.query.filter_by(id=id).one()

    # Dann initialisieren wir das WTFoms-Objekt, das uns die meiste Arbeit
    # abnimmt. Falls nicht schon zu speichernde Daten per POST daherkommen,
    # initialisieren wir die Felder mit den Daten aus der Datenbank.
    form = CdForm(obj=cd)

    # Für das Dropdown laden wir noch dynamisch die Auswahlmöglichkeiten aus
    # der Interpreten-Tabelle.
    form.interpret_id.choices = [(str(i.id), i.display_name) for i in Interpret.query]

    # Falls Daten per POST zum Speichern geschickt wurden und die Validierung
    # erfolgreich war, schreiben wir den Inhalt der Formularfelder zurück in
    # die Datenbank und leiten wieder auf die Liste der CDs um.
    if form.validate_on_submit():
        cd.title = form.data["title"]
        cd.interpret_id = form.data["interpret_id"]
        db.session.commit()
        return redirect("/")

    # Andernfalls geben wir einfach das Formular aus. Hier ist der Parameter
    # für das Template unser WTForms-Objekt.
    return render_template("cd_edit.html", form=form)
