#!/usr/bin/python3
# =============================================================================
# Initialisierung und Demo-Anwendung zur CD-Datenbank
# =============================================================================
# Copyright © 2019 Reinhard Müller <reinhard@fsfe.org>
# This work is free. You can redistribute it and/or modify it under the
# terms of the Do What The Fuck You Want To Public License, Version 2,
# as published by Sam Hocevar. See http://www.wtfpl.net/ for more details.
# =============================================================================

# Erstmal alles importieren
from cd import Cd, Interpret, db

print("Datenbanktabellen anlegen...")
db.create_all()

print("Tabelle 'interpret' befüllen...")
jl = Interpret(first_name="John", last_name="Lennon")
fz = Interpret(first_name="Frank", last_name="Zappa")
db.session.add(jl)
db.session.add(fz)
db.session.commit()

print("Ein paar Abfragen zum Test...")
print("  Interpret.query.count() =", Interpret.query.count())
print("  Interpret.query.all() =", Interpret.query.all())
print("  Interpret.query.first() =", Interpret.query.first())
print("  Interpret.query.first().last_name =", Interpret.query.first().last_name)

# Bedingungen sind sogar über Hybrid-Properties möglich.
print("  Interpret.query.filter(Interpret.display_name.like('Zappa%')).all() =",
      Interpret.query.filter(Interpret.display_name.like('Zappa%')).all())

print("Tabelle 'cd' befüllen...")
db.session.add(Cd(title="Double Fantasy", interpret_id=1))
db.session.add(Cd(title="Joe's Garage", interpret_id=2))
db.session.commit()

print("Ein paar Abfragen zum Test...")
print("  Cd.query.all() =", Cd.query.all())
cd1 = Cd.query.first()
print("  cd1 = Cd.query.first() =", cd1)
print("  cd1.title =", cd1.title)
print("  cd1.interpret_id =", cd1.interpret_id)
print("  cd1.interpret =", cd1.interpret)
print("  cd1.interpret.last_name =", cd1.interpret.last_name)

print("""
Jetzt ist die Datenbank initialisiert, und der in Flask eingebaute Webserver
kann gestartet werden:
$ export FLASK_APP=cd.py
$ export FLASK_DEBUG=1
$ flask run

Die Anwendung kann dann in einem Webbrowser unter http://localhost:5000/
bewundert werden.

Noch Fragen? reinhard (at) fsfe.org

Die FSFE unterstützen: https://my.fsfe.org/support
""")
