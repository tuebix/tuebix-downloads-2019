#!/bin/bash

CPUs=$( grep -c processor < /proc/cpuinfo )
n=20000000
    
    for i in ` eval echo {1..$CPUs} ` ; do
    echo $i $( (
	yes | 
	head -$n |
	cat -n |
#	time   parallel -j$i --line-buffer  --pipe --round-robin "sed 's/.*/& &/'" | 
        bash -c 'time -p parallel -j'$i' --line-buffer  --pipe --round-robin "sed '\''s/.*/& &/'\''" '  |
	sort -n -S 2G | 
	md5sum
	) 2>&1
    )
done

